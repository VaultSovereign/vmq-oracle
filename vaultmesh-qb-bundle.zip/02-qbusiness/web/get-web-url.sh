#!/usr/bin/env bash
set -euo pipefail

APP_ID="${1:-}"
if [[ -z "$APP_ID" ]]; then
  echo "Usage: $0 <APP_ID> [WEB_EXPERIENCE_ID]" >&2
  exit 1
fi

REGION="${REGION:-eu-west-1}"
WEB_ID="${2:-}"

if [[ -z "$WEB_ID" ]]; then
  WEB_ID=$(aws qbusiness list-web-experiences \
    --region "$REGION" \
    --application-id "$APP_ID" \
    --query 'webExperiences[0].webExperienceId' --output text)
fi

echo "Using web experience: $WEB_ID"
aws qbusiness get-web-experience \
  --region "$REGION" \
  --application-id "$APP_ID" \
  --web-experience-id "$WEB_ID"

